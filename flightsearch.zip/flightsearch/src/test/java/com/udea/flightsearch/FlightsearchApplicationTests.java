package com.udea.flightsearch;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FlightsearchApplicationTests {

	@Test
	void contextLoads() {
	}

}
